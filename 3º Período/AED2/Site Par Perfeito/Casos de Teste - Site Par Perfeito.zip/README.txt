Arquivo zip gerado em: 22/01/2022 16:47:17 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Site Par Perfeito
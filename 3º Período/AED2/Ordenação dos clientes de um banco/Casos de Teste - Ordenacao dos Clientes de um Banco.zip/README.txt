Arquivo zip gerado em: 20/01/2022 13:33:04 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Ordenação dos Clientes de um Banco